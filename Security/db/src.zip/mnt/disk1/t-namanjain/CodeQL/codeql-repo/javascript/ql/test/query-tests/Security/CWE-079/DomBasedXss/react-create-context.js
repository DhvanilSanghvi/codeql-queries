import { createContext } from 'react';

export let MyContext = createContext({root: null});
