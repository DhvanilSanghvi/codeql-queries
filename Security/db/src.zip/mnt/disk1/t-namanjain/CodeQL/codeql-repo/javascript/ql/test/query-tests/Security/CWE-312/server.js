require("foo");
(function (req, res){})
