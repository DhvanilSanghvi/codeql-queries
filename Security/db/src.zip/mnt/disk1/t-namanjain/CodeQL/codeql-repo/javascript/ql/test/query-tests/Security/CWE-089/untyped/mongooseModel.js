import mongoose from 'mongoose';

export const MyModel = mongoose.model('MyModel', getSchema());
