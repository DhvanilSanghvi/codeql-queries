// OK
window.location = window.location.toString().split('?')[0] + '?' + boxes.value;
