var Hapi = require('hapi');
var server = new Hapi.Server();
server.route({
    handler: function (request, reply){

    }});
