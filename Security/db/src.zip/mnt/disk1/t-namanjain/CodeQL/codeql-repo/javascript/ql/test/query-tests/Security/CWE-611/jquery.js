function test() {
  var src = document.location.search;

  $.parseXML(src);
}
