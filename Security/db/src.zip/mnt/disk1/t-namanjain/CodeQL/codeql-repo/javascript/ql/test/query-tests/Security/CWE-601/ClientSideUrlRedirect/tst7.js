// NOT OK
new Worker(document.location.search);

// NOT OK
$("<script>").attr("src", document.location.search);
