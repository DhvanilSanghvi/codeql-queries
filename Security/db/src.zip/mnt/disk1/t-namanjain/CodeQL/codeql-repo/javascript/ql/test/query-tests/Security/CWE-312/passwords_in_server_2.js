require("foo");
(function (req, res){});
console.log(password);
