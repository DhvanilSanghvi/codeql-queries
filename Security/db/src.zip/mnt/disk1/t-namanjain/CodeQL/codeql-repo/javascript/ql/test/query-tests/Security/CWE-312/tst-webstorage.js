localStorage.x = data.password;
localStorage.setItem('x', data.password)
sessionStorage.x = data.password;
sessionStorage.setItem('x', data.password)
