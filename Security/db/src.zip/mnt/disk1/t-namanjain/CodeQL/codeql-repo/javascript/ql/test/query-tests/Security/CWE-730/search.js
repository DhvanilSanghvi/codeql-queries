module.someOtherExport = true;


export function search(query) {
	// Do nothing!
}
