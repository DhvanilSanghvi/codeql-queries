require("foo");
console.log(password);
