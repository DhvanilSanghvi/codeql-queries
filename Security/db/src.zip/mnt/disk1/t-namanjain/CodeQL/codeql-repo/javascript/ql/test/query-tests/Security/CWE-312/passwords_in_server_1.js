var express = require('express');
var app = express();
app.get('/some/path', function() {
})

console.log(password);
