import foo from "foo";
window.location;
