// NOT OK
document.location = document.location.hash.substring(1)
