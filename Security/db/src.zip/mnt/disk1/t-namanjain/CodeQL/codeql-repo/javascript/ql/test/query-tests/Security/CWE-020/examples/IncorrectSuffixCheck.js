function endsWith(x, y) {
  return x.lastIndexOf(y) === x.length - y.length;
}
