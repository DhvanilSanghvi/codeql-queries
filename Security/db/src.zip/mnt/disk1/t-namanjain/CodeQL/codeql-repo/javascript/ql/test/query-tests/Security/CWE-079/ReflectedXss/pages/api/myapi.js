export default function handler(req, res) {
    res.send(req.url);
}